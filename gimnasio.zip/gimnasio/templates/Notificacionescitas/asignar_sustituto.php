<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Notificacionescita[]|\Cake\Collection\CollectionInterface $notificacionescitas
 */
?>
<div class="notificacionescitas index content">
    
</div>
